<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('asistencias', function (Blueprint $table) {
            if (Schema::hasColumn('asistencias', 'registrado_por')) {
                $table->unsignedBigInteger('registrado_por')->nullable()->change();
            }
        });
    }

    public function down(): void
    {
        Schema::table('asistencias', function (Blueprint $table) {
            if (Schema::hasColumn('asistencias', 'registrado_por')) {
                $table->unsignedBigInteger('registrado_por')->nullable(false)->change();
            }
        });
    }
};
