<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;
use Inertia\Middleware;

class HandleInertiaRequests extends Middleware
{
	/**
	 * The root template that is loaded on the first page visit.
	 *
	 * @see https://inertiajs.com/server-side-setup
	 */
	protected $rootView = 'app';

	/**
	 * Determines the current asset version.
	 */
	public function version(Request $request): string|null
	{
		return parent::version($request);
	}

	/**
	 * Define the props that are shared by default.
	 */
	public function share(Request $request): array
	{
		return array_merge(parent::share($request), [
			'auth' => [
				'user' => $request->user(),
			],
			'flash' => [
				'success' => fn () => $request->session()->get('success'),
				'error' => fn () => $request->session()->get('error'),
			],
		]);
	}
}

